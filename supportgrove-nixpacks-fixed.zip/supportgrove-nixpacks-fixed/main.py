#!/usr/bin/env python3
"""
SupportGrove Backend - Nixpacks Compatible
Optimized for Railway deployment with Nixpacks
"""

import os
import sqlite3
import json
import uuid
import re
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from flask_cors import CORS

# Create Flask application
app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'supportgrove-secret-key')

# CORS configuration
cors_origins = os.environ.get('CORS_ORIGINS', '*')
if cors_origins == '*':
    CORS(app)
else:
    CORS(app, origins=cors_origins.split(','))

# Database initialization
def init_database():
    """Initialize SQLite database"""
    conn = sqlite3.connect('supportgrove.db')
    cursor = conn.cursor()
    
    # Create stories table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS stories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            category TEXT NOT NULL,
            hashtags TEXT,
            author_name TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            reaction_hearts INTEGER DEFAULT 0,
            reaction_hugs INTEGER DEFAULT 0,
            reaction_sparkles INTEGER DEFAULT 0,
            comment_count INTEGER DEFAULT 0
        )
    ''')
    
    # Create comments table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            story_id INTEGER NOT NULL,
            parent_id INTEGER,
            content TEXT NOT NULL,
            author_name TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (story_id) REFERENCES stories (id)
        )
    ''')
    
    # Create categories table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT NOT NULL,
            color TEXT NOT NULL,
            icon TEXT NOT NULL
        )
    ''')
    
    # Create sharing table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sharing (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            share_id TEXT NOT NULL UNIQUE,
            story_id INTEGER NOT NULL,
            sender_name TEXT,
            personal_message TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP,
            view_count INTEGER DEFAULT 0,
            FOREIGN KEY (story_id) REFERENCES stories (id)
        )
    ''')
    
    conn.commit()
    
    # Seed categories if empty
    cursor.execute("SELECT COUNT(*) FROM categories")
    if cursor.fetchone()[0] == 0:
        categories = [
            ('Depression & Anxiety', 'Experiences with depression, anxiety disorders, panic attacks, and mood-related challenges', 'blue', 'cloud-rain'),
            ('Trauma & Healing', 'Experiences with PTSD, childhood trauma, abuse recovery, racial trauma, sexism, religious abuse, gender fluidity shaming, and multigenerational family dysfunctionality', 'purple', 'heart'),
            ('Addiction & Recovery', 'Stories of addiction, substance abuse recovery, behavioral addictions, and sobriety journeys', 'green', 'refresh-cw'),
            ('Relationships & Family', 'Challenges with family dynamics, romantic relationships, friendships, and social connections', 'pink', 'users'),
            ('Work & Life Balance', 'Workplace stress, burnout, career transitions, and finding balance in daily life', 'orange', 'briefcase'),
            ('Identity & Self-Worth', 'Self-esteem issues, identity exploration, body image, and personal growth journeys', 'teal', 'user')
        ]
        
        for name, desc, color, icon in categories:
            cursor.execute('INSERT INTO categories (name, description, color, icon) VALUES (?, ?, ?, ?)', 
                         (name, desc, color, icon))
        conn.commit()
    
    conn.close()

# Utility functions
def sanitize_content(content):
    if not content:
        return ""
    content = re.sub(r'<[^>]+>', '', content)
    return content.strip()[:10000]

def validate_pseudonym(pseudonym):
    if not pseudonym:
        return True, "Anonymous"
    pseudonym = pseudonym.strip()
    if len(pseudonym) > 50:
        return False, "Too long"
    return True, pseudonym

# Routes
@app.route('/')
def home():
    return jsonify({
        'message': 'SupportGrove API',
        'status': 'running',
        'version': '1.0.0'
    })

@app.route('/health')
def health():
    return jsonify({'status': 'healthy'})

@app.route('/api/stories', methods=['GET'])
def get_stories():
    try:
        category = request.args.get('category')
        limit = int(request.args.get('limit', 20))
        offset = int(request.args.get('offset', 0))
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        if category:
            cursor.execute('''
                SELECT id, title, content, category, hashtags, author_name,
                       created_at, reaction_hearts, reaction_hugs, reaction_sparkles, comment_count
                FROM stories WHERE category = ? ORDER BY created_at DESC LIMIT ? OFFSET ?
            ''', (category, limit, offset))
        else:
            cursor.execute('''
                SELECT id, title, content, category, hashtags, author_name,
                       created_at, reaction_hearts, reaction_hugs, reaction_sparkles, comment_count
                FROM stories ORDER BY created_at DESC LIMIT ? OFFSET ?
            ''', (limit, offset))
        
        stories = []
        for row in cursor.fetchall():
            stories.append({
                'id': row[0],
                'title': row[1],
                'content': row[2],
                'category': row[3],
                'hashtags': json.loads(row[4]) if row[4] else [],
                'author_name': row[5] or 'Anonymous',
                'created_at': row[6],
                'reactions': {'hearts': row[7] or 0, 'hugs': row[8] or 0, 'sparkles': row[9] or 0},
                'comment_count': row[10] or 0
            })
        
        conn.close()
        return jsonify({'success': True, 'stories': stories})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/stories', methods=['POST'])
def create_story():
    try:
        data = request.get_json()
        if not data or not all(data.get(field) for field in ['title', 'content', 'category']):
            return jsonify({'success': False, 'error': 'Missing required fields'}), 400
        
        title = sanitize_content(data['title'])
        content = sanitize_content(data['content'])
        category = data['category']
        hashtags = json.dumps(data.get('hashtags', []))
        author_name = data.get('author_name')
        
        if author_name:
            is_valid, author_name = validate_pseudonym(author_name)
            if not is_valid:
                return jsonify({'success': False, 'error': 'Invalid author name'}), 400
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO stories (title, content, category, hashtags, author_name)
            VALUES (?, ?, ?, ?, ?)
        ''', (title, content, category, hashtags, author_name))
        
        story_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'story_id': story_id}), 201
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/stories/<int:story_id>/reactions', methods=['POST'])
def update_reaction(story_id):
    try:
        data = request.get_json()
        if not data or 'type' not in data:
            return jsonify({'success': False, 'error': 'Reaction type required'}), 400
        
        reaction_type = data['type']
        increment = data.get('increment', True)
        
        if reaction_type not in ['hearts', 'hugs', 'sparkles']:
            return jsonify({'success': False, 'error': 'Invalid reaction type'}), 400
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        column = f'reaction_{reaction_type}'
        operation = '+' if increment else '-'
        cursor.execute(f'UPDATE stories SET {column} = MAX(0, {column} {operation} 1) WHERE id = ?', (story_id,))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/stories/<int:story_id>/comments', methods=['GET'])
def get_comments(story_id):
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, parent_id, content, author_name, created_at
            FROM comments WHERE story_id = ? ORDER BY created_at ASC
        ''', (story_id,))
        
        comments = []
        for row in cursor.fetchall():
            comments.append({
                'id': row[0],
                'parent_id': row[1],
                'content': row[2],
                'author_name': row[3] or 'Anonymous',
                'created_at': row[4],
                'replies': []
            })
        
        # Organize threaded comments
        comment_dict = {c['id']: c for c in comments}
        threaded = []
        
        for comment in comments:
            if comment['parent_id'] is None:
                threaded.append(comment)
            else:
                parent = comment_dict.get(comment['parent_id'])
                if parent:
                    parent['replies'].append(comment)
        
        conn.close()
        return jsonify({'success': True, 'comments': threaded})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/stories/<int:story_id>/comments', methods=['POST'])
def create_comment(story_id):
    try:
        data = request.get_json()
        if not data or not data.get('content'):
            return jsonify({'success': False, 'error': 'Content required'}), 400
        
        content = sanitize_content(data['content'])
        author_name = data.get('author_name')
        parent_id = data.get('parent_id')
        
        if author_name:
            is_valid, author_name = validate_pseudonym(author_name)
            if not is_valid:
                return jsonify({'success': False, 'error': 'Invalid author name'}), 400
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO comments (story_id, parent_id, content, author_name)
            VALUES (?, ?, ?, ?)
        ''', (story_id, parent_id, content, author_name))
        
        # Update comment count
        cursor.execute('UPDATE stories SET comment_count = (SELECT COUNT(*) FROM comments WHERE story_id = ?) WHERE id = ?', 
                      (story_id, story_id))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True}), 201
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/categories', methods=['GET'])
def get_categories():
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        cursor.execute('''
            SELECT c.id, c.name, c.description, c.color, c.icon, COUNT(s.id) as story_count
            FROM categories c LEFT JOIN stories s ON c.name = s.category
            GROUP BY c.id ORDER BY c.name
        ''')
        
        categories = []
        for row in cursor.fetchall():
            categories.append({
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'color': row[3],
                'icon': row[4],
                'story_count': row[5]
            })
        
        conn.close()
        return jsonify({'success': True, 'categories': categories})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/stories/<int:story_id>/share', methods=['POST'])
def create_share(story_id):
    try:
        data = request.get_json() or {}
        share_id = str(uuid.uuid4())
        sender_name = data.get('sender_name')
        personal_message = data.get('personal_message')
        expires_in_days = data.get('expires_in_days', 30)
        
        expires_at = datetime.utcnow() + timedelta(days=expires_in_days) if expires_in_days else None
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO sharing (share_id, story_id, sender_name, personal_message, expires_at)
            VALUES (?, ?, ?, ?, ?)
        ''', (share_id, story_id, sender_name, personal_message, expires_at))
        
        conn.commit()
        conn.close()
        
        base_url = os.environ.get('FRONTEND_URL', 'https://supportgrove.online')
        share_url = f"{base_url}/shared/{share_id}"
        
        return jsonify({
            'success': True,
            'share_data': {
                'share_id': share_id,
                'share_url': share_url,
                'expires_at': expires_at.isoformat() if expires_at else None
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/shared/<share_id>', methods=['GET'])
def get_shared_story(share_id):
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        cursor.execute('''
            SELECT s.sender_name, s.personal_message, s.expires_at, s.view_count,
                   st.id, st.title, st.content, st.category, st.hashtags, st.author_name,
                   st.created_at, st.reaction_hearts, st.reaction_hugs, st.reaction_sparkles, st.comment_count
            FROM sharing s JOIN stories st ON s.story_id = st.id WHERE s.share_id = ?
        ''', (share_id,))
        
        row = cursor.fetchone()
        if not row:
            conn.close()
            return jsonify({'success': False, 'error': 'Not found'}), 404
        
        # Check expiration
        if row[2]:
            expires_at = datetime.fromisoformat(row[2])
            if datetime.utcnow() > expires_at:
                conn.close()
                return jsonify({'success': False, 'error': 'Expired'}), 404
        
        # Increment view count
        cursor.execute('UPDATE sharing SET view_count = view_count + 1 WHERE share_id = ?', (share_id,))
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'data': {
                'share_info': {
                    'sender_name': row[0],
                    'personal_message': row[1],
                    'view_count': row[3] + 1
                },
                'story': {
                    'id': row[4],
                    'title': row[5],
                    'content': row[6],
                    'category': row[7],
                    'hashtags': json.loads(row[8]) if row[8] else [],
                    'author_name': row[9] or 'Anonymous',
                    'created_at': row[10],
                    'reactions': {'hearts': row[11] or 0, 'hugs': row[12] or 0, 'sparkles': row[13] or 0},
                    'comment_count': row[14] or 0
                }
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# Initialize database on startup
init_database()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)

