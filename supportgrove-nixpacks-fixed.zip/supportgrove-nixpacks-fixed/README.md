# SupportGrove Backend - Nixpacks Fixed

This backend is specifically designed to work with Nixpacks on Railway.com with guaranteed build plan generation.

## 🔧 Nixpacks Issues Fixed

### **❌ Previous Issues:**
1. **Malformed directory structure** - `{src` instead of `src`
2. **Complex nixpacks.toml** - Overriding Nixpacks auto-detection
3. **Multiple entry points** - Confusing Nixpacks detection
4. **Unnecessary files** - runtime.txt, Procfile causing conflicts

### **✅ Solutions Applied:**
1. **Clean file structure** - Only essential files
2. **Automatic detection** - Let Nixpacks handle everything
3. **Single entry point** - `main.py` as the only Python file
4. **Minimal requirements** - Only necessary dependencies

## 📁 Clean Structure

```
supportgrove-nixpacks-fixed/
├── main.py              # Single Flask application file
├── requirements.txt     # Minimal dependencies
├── .env.example        # Environment variables
└── README.md           # This guide
```

## 🚀 Guaranteed Nixpacks Detection

### **requirements.txt** (Nixpacks Python detection)
```
Flask==3.0.0
Flask-CORS==4.0.0
gunicorn==21.2.0
```

### **main.py** (Single entry point)
- Complete Flask application in one file
- All routes and database logic included
- Automatic database initialization
- Health check endpoints

## ✨ Complete SupportGrove Features

- ✅ Anonymous story sharing
- ✅ Six support categories with inclusive trauma descriptions
- ✅ Threaded commenting system
- ✅ Story reactions (hearts, hugs, sparkles)
- ✅ Story forwarding with shareable links
- ✅ Content sanitization and validation
- ✅ SQLite database with automatic setup

## 🎯 Railway Deployment

### **Step 1: Upload to GitHub**
```bash
git add supportgrove-nixpacks-fixed/
git commit -m "Add Nixpacks-fixed SupportGrove backend"
git push origin main
```

### **Step 2: Deploy to Railway**
1. Go to [railway.app/new](https://railway.app/new)
2. Click "Deploy from GitHub repo"
3. Select your repository
4. **Set root directory**: `supportgrove-nixpacks-fixed`
5. **Nixpacks will automatically detect and build!**

### **Step 3: Environment Variables**
Set in Railway dashboard:
- `SECRET_KEY` - Your Flask secret key
- `CORS_ORIGINS` - `https://supportgrove.online`
- `FRONTEND_URL` - `https://supportgrove.online`

## 📡 API Endpoints

- `GET /` - API status
- `GET /health` - Health check
- `GET /api/stories` - Get stories
- `POST /api/stories` - Create story
- `POST /api/stories/{id}/reactions` - Add reactions
- `GET /api/stories/{id}/comments` - Get comments
- `POST /api/stories/{id}/comments` - Create comment
- `GET /api/categories` - Get categories
- `POST /api/stories/{id}/share` - Create share link
- `GET /api/shared/{share_id}` - Get shared story

## 🔍 Why This Works

### **Nixpacks Auto-Detection:**
1. **Finds requirements.txt** → Detects Python project
2. **Finds main.py** → Uses as entry point
3. **Installs dependencies** → `pip install -r requirements.txt`
4. **Starts application** → `python main.py`

### **No Configuration Conflicts:**
- No nixpacks.toml to override detection
- No Procfile to confuse process management
- No runtime.txt to conflict with auto-detection
- Clean directory structure

This backend will deploy successfully on Railway with Nixpacks! 🚀

