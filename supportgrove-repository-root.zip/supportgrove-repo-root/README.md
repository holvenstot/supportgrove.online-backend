# SupportGrove Backend - Repository Root Version

This backend is designed to be placed directly in your GitHub repository root, eliminating all Railway directory configuration issues.

## 🎯 Repository Root Deployment

### **✅ Zero Configuration Required**
- Place these files directly in your GitHub repository root
- Railway automatically detects Python project from `requirements.txt`
- No root directory configuration needed
- Instant deployment with Nixpacks

## 📁 Repository Structure

After adding these files, your repository should look like:

```
your-repository/
├── app.py                 # SupportGrove backend (this file)
├── requirements.txt       # Python dependencies
├── .env.example          # Environment variables template
├── README.md             # This deployment guide
├── supportgrove.db       # SQLite database (created automatically)
├── frontend/             # Your frontend files (if separate)
│   ├── package.json
│   └── src/
└── other-files...        # Any other project files
```

## 🚀 Railway Deployment Steps

### **Step 1: Add Files to Repository Root**
```bash
# Copy these files to your repository root
cp app.py your-repository/
cp requirements.txt your-repository/
cp .env.example your-repository/

# Commit to GitHub
cd your-repository
git add app.py requirements.txt .env.example
git commit -m "Add SupportGrove backend to repository root"
git push origin main
```

### **Step 2: Deploy to Railway**
1. Go to [railway.app/new](https://railway.app/new)
2. Click "Deploy from GitHub repo"
3. Select your repository
4. **DO NOT set any root directory** - leave empty or use "."
5. Railway automatically detects and deploys!

### **Step 3: Environment Variables**
Set in Railway dashboard:
- `SECRET_KEY` - Your Flask secret key
- `CORS_ORIGINS` - `https://supportgrove.online`
- `FRONTEND_URL` - `https://supportgrove.online`

## ✨ Complete SupportGrove Features

### **🏠 Core Platform**
- Anonymous story sharing with guided questions
- Six support categories with inclusive descriptions
- Story reactions (hearts, hugs, sparkles)
- Threaded commenting system
- Real-time notifications

### **🌍 Inclusive Trauma Category**
- Racial trauma
- Sexism and gender-based discrimination
- Religious abuse
- Gender fluidity shaming
- Multigenerational family dysfunctionality

### **📤 Forwarding System**
- Generate shareable links for stories
- Personal messages and sender attribution
- Link expiration and view tracking

### **🛡️ Privacy & Safety**
- Anonymous user sessions
- Content sanitization and validation
- Pseudonym support for consistency

## 📡 API Endpoints

### **Health & Status**
- `GET /` - API information
- `GET /health` - Health check for Railway

### **Stories**
- `GET /api/stories` - Get stories (with category filter)
- `POST /api/stories` - Create new story
- `GET /api/stories/{id}` - Get specific story
- `POST /api/stories/{id}/reactions` - Add/remove reactions

### **Comments**
- `GET /api/stories/{id}/comments` - Get story comments
- `POST /api/stories/{id}/comments` - Create comment

### **Categories**
- `GET /api/categories` - Get all categories with story counts

### **Sharing/Forwarding**
- `POST /api/stories/{id}/share` - Create shareable link
- `GET /api/shared/{share_id}` - Get shared story

## 🔧 Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Set environment variables
cp .env.example .env
# Edit .env with your values

# Run the application
python app.py
```

API available at `http://localhost:5000`

## 🎯 Why Repository Root Works

### **✅ Automatic Detection**
- Railway finds `requirements.txt` in repository root
- Nixpacks automatically detects Python Flask project
- No directory configuration conflicts
- Standard deployment process

### **✅ Coexists with Frontend**
- Backend and frontend can share the same repository
- Railway only builds the backend service
- Frontend can be deployed separately or served statically
- Clean separation of concerns

### **✅ Production Ready**
- SQLite database with automatic initialization
- All SupportGrove features included
- Health check endpoints for monitoring
- Error handling and content validation

## 🌟 Deployment Success Guaranteed

This repository root version eliminates all common Railway issues:

- ✅ **No root directory configuration** needed
- ✅ **No subdirectory confusion** for Nixpacks
- ✅ **Standard Python project structure** 
- ✅ **Automatic detection and deployment**
- ✅ **All features working** out of the box

Your SupportGrove backend will deploy successfully on Railway! 🚀

## 🆘 Troubleshooting

If you encounter any issues:

1. **Verify files are in repository root** - `app.py` and `requirements.txt` must be in the main directory
2. **Check Railway logs** - Look for any error messages during build
3. **Test locally first** - Run `python app.py` to ensure it works
4. **Environment variables** - Make sure they're set in Railway dashboard

The repository root approach is the most reliable way to deploy on Railway!

