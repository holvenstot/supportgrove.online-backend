#!/usr/bin/env python3
"""
SupportGrove Backend - Repository Root Version
Optimized for Railway deployment from GitHub repository root
"""

import os
import sqlite3
import json
import uuid
import re
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from flask_cors import CORS

# Create Flask application
app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'supportgrove-secret-key')

# CORS configuration
cors_origins = os.environ.get('CORS_ORIGINS', '*')
if cors_origins == '*':
    CORS(app)
else:
    CORS(app, origins=cors_origins.split(','))

# Database initialization
def init_database():
    """Initialize SQLite database with all tables"""
    conn = sqlite3.connect('supportgrove.db')
    cursor = conn.cursor()
    
    # Create stories table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS stories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            category TEXT NOT NULL,
            hashtags TEXT,
            author_name TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            reaction_hearts INTEGER DEFAULT 0,
            reaction_hugs INTEGER DEFAULT 0,
            reaction_sparkles INTEGER DEFAULT 0,
            comment_count INTEGER DEFAULT 0
        )
    ''')
    
    # Create comments table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            story_id INTEGER NOT NULL,
            parent_id INTEGER,
            content TEXT NOT NULL,
            author_name TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (story_id) REFERENCES stories (id),
            FOREIGN KEY (parent_id) REFERENCES comments (id)
        )
    ''')
    
    # Create categories table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT NOT NULL,
            color TEXT NOT NULL,
            icon TEXT NOT NULL
        )
    ''')
    
    # Create sharing table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sharing (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            share_id TEXT NOT NULL UNIQUE,
            story_id INTEGER NOT NULL,
            sender_name TEXT,
            personal_message TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP,
            view_count INTEGER DEFAULT 0,
            FOREIGN KEY (story_id) REFERENCES stories (id)
        )
    ''')
    
    # Create notifications table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            story_id INTEGER,
            comment_id INTEGER,
            type TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            read_at TIMESTAMP,
            FOREIGN KEY (story_id) REFERENCES stories (id),
            FOREIGN KEY (comment_id) REFERENCES comments (id)
        )
    ''')
    
    conn.commit()
    
    # Seed categories if empty
    cursor.execute("SELECT COUNT(*) FROM categories")
    if cursor.fetchone()[0] == 0:
        seed_categories(cursor)
        conn.commit()
    
    conn.close()

def seed_categories(cursor):
    """Seed initial categories with inclusive descriptions"""
    categories = [
        {
            'name': 'Depression & Anxiety',
            'description': 'Experiences with depression, anxiety disorders, panic attacks, and mood-related challenges',
            'color': 'blue',
            'icon': 'cloud-rain'
        },
        {
            'name': 'Trauma & Healing',
            'description': 'Experiences with PTSD, childhood trauma, abuse recovery, racial trauma, sexism, religious abuse, gender fluidity shaming, and multigenerational family dysfunctionality',
            'color': 'purple',
            'icon': 'heart'
        },
        {
            'name': 'Addiction & Recovery',
            'description': 'Stories of addiction, substance abuse recovery, behavioral addictions, and sobriety journeys',
            'color': 'green',
            'icon': 'refresh-cw'
        },
        {
            'name': 'Relationships & Family',
            'description': 'Challenges with family dynamics, romantic relationships, friendships, and social connections',
            'color': 'pink',
            'icon': 'users'
        },
        {
            'name': 'Work & Life Balance',
            'description': 'Workplace stress, burnout, career transitions, and finding balance in daily life',
            'color': 'orange',
            'icon': 'briefcase'
        },
        {
            'name': 'Identity & Self-Worth',
            'description': 'Self-esteem issues, identity exploration, body image, and personal growth journeys',
            'color': 'teal',
            'icon': 'user'
        }
    ]
    
    for category in categories:
        cursor.execute('''
            INSERT INTO categories (name, description, color, icon)
            VALUES (?, ?, ?, ?)
        ''', (category['name'], category['description'], category['color'], category['icon']))

# Utility functions
def sanitize_content(content):
    """Basic content sanitization"""
    if not content:
        return ""
    content = re.sub(r'<[^>]+>', '', content)
    if len(content) > 10000:
        content = content[:10000] + "..."
    return content.strip()

def validate_pseudonym(pseudonym):
    """Validate pseudonym"""
    if not pseudonym:
        return True, "Anonymous"
    
    pseudonym = pseudonym.strip()
    if len(pseudonym) > 50:
        return False, "Pseudonym must be 50 characters or less"
    if len(pseudonym) < 2:
        return False, "Pseudonym must be at least 2 characters"
    
    return True, pseudonym

# Health check endpoints
@app.route('/')
def root():
    """Root endpoint"""
    return jsonify({
        'message': 'SupportGrove API is running',
        'version': '1.0.0',
        'repository_root': True,
        'endpoints': {
            'health': '/health',
            'stories': '/api/stories',
            'comments': '/api/comments',
            'categories': '/api/categories',
            'sharing': '/api/sharing'
        }
    })

@app.route('/health')
@app.route('/api/health')
def health_check():
    """Health check endpoint for Railway"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0',
        'repository_root': True
    })

# Stories endpoints
@app.route('/api/stories', methods=['GET'])
def get_stories():
    """Get stories with optional category filter"""
    try:
        category = request.args.get('category')
        limit = int(request.args.get('limit', 20))
        offset = int(request.args.get('offset', 0))
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        if category:
            cursor.execute('''
                SELECT id, title, content, category, hashtags, author_name,
                       created_at, updated_at, reaction_hearts, reaction_hugs,
                       reaction_sparkles, comment_count
                FROM stories WHERE category = ?
                ORDER BY created_at DESC
                LIMIT ? OFFSET ?
            ''', (category, limit, offset))
        else:
            cursor.execute('''
                SELECT id, title, content, category, hashtags, author_name,
                       created_at, updated_at, reaction_hearts, reaction_hugs,
                       reaction_sparkles, comment_count
                FROM stories
                ORDER BY created_at DESC
                LIMIT ? OFFSET ?
            ''', (limit, offset))
        
        rows = cursor.fetchall()
        stories = []
        
        for row in rows:
            stories.append({
                'id': row[0],
                'title': row[1],
                'content': row[2],
                'category': row[3],
                'hashtags': json.loads(row[4]) if row[4] else [],
                'author_name': row[5] or 'Anonymous',
                'created_at': row[6],
                'updated_at': row[7],
                'reactions': {
                    'hearts': row[8] or 0,
                    'hugs': row[9] or 0,
                    'sparkles': row[10] or 0
                },
                'comment_count': row[11] or 0
            })
        
        conn.close()
        
        return jsonify({
            'success': True,
            'stories': stories,
            'count': len(stories)
        })
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/stories', methods=['POST'])
def create_story():
    """Create a new story"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400
        
        # Validate required fields
        required_fields = ['title', 'content', 'category']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'success': False, 'error': f'Missing required field: {field}'}), 400
        
        title = sanitize_content(data['title'])
        content = sanitize_content(data['content'])
        category = data['category']
        hashtags = json.dumps(data.get('hashtags', []))
        author_name = data.get('author_name')
        
        if author_name:
            is_valid, author_name = validate_pseudonym(author_name)
            if not is_valid:
                return jsonify({'success': False, 'error': f'Invalid author name: {author_name}'}), 400
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO stories (title, content, category, hashtags, author_name)
            VALUES (?, ?, ?, ?, ?)
        ''', (title, content, category, hashtags, author_name))
        
        story_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'story_id': story_id,
            'message': 'Story created successfully'
        }), 201
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/stories/<int:story_id>', methods=['GET'])
def get_story(story_id):
    """Get a specific story by ID"""
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, title, content, category, hashtags, author_name,
                   created_at, updated_at, reaction_hearts, reaction_hugs,
                   reaction_sparkles, comment_count
            FROM stories WHERE id = ?
        ''', (story_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return jsonify({'success': False, 'error': 'Story not found'}), 404
        
        story = {
            'id': row[0],
            'title': row[1],
            'content': row[2],
            'category': row[3],
            'hashtags': json.loads(row[4]) if row[4] else [],
            'author_name': row[5] or 'Anonymous',
            'created_at': row[6],
            'updated_at': row[7],
            'reactions': {
                'hearts': row[8] or 0,
                'hugs': row[9] or 0,
                'sparkles': row[10] or 0
            },
            'comment_count': row[11] or 0
        }
        
        return jsonify({
            'success': True,
            'story': story
        })
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/stories/<int:story_id>/reactions', methods=['POST'])
def add_reaction(story_id):
    """Add or remove reaction to story"""
    try:
        data = request.get_json()
        if not data or 'type' not in data:
            return jsonify({'success': False, 'error': 'Reaction type required'}), 400
        
        reaction_type = data['type']
        increment = data.get('increment', True)
        
        valid_reactions = ['hearts', 'hugs', 'sparkles']
        if reaction_type not in valid_reactions:
            return jsonify({'success': False, 'error': f'Invalid reaction type'}), 400
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        column_map = {'hearts': 'reaction_hearts', 'hugs': 'reaction_hugs', 'sparkles': 'reaction_sparkles'}
        column = column_map[reaction_type]
        operation = '+' if increment else '-'
        
        cursor.execute(f'''
            UPDATE stories 
            SET {column} = MAX(0, {column} {operation} 1)
            WHERE id = ?
        ''', (story_id,))
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': f'Reaction {reaction_type} {"added" if increment else "removed"}'
        })
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# Comments endpoints
@app.route('/api/stories/<int:story_id>/comments', methods=['GET'])
def get_comments(story_id):
    """Get comments for a story"""
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, story_id, parent_id, content, author_name, created_at
            FROM comments 
            WHERE story_id = ?
            ORDER BY created_at ASC
        ''', (story_id,))
        
        rows = cursor.fetchall()
        comments = []
        
        for row in rows:
            comments.append({
                'id': row[0],
                'story_id': row[1],
                'parent_id': row[2],
                'content': row[3],
                'author_name': row[4] or 'Anonymous',
                'created_at': row[5],
                'replies': []
            })
        
        # Organize into threaded structure
        comment_dict = {comment['id']: comment for comment in comments}
        threaded_comments = []
        
        for comment in comments:
            if comment['parent_id'] is None:
                threaded_comments.append(comment)
            else:
                parent = comment_dict.get(comment['parent_id'])
                if parent:
                    parent['replies'].append(comment)
        
        conn.close()
        
        return jsonify({
            'success': True,
            'comments': threaded_comments,
            'count': len(threaded_comments)
        })
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/stories/<int:story_id>/comments', methods=['POST'])
def create_comment(story_id):
    """Create a comment"""
    try:
        data = request.get_json()
        if not data or not data.get('content'):
            return jsonify({'success': False, 'error': 'Comment content required'}), 400
        
        content = sanitize_content(data['content'])
        author_name = data.get('author_name')
        parent_id = data.get('parent_id')
        
        if author_name:
            is_valid, author_name = validate_pseudonym(author_name)
            if not is_valid:
                return jsonify({'success': False, 'error': f'Invalid author name: {author_name}'}), 400
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO comments (story_id, parent_id, content, author_name)
            VALUES (?, ?, ?, ?)
        ''', (story_id, parent_id, content, author_name))
        
        comment_id = cursor.lastrowid
        
        # Update story comment count
        cursor.execute('''
            UPDATE stories 
            SET comment_count = (SELECT COUNT(*) FROM comments WHERE story_id = ?)
            WHERE id = ?
        ''', (story_id, story_id))
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'comment_id': comment_id,
            'message': 'Comment created successfully'
        }), 201
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# Categories endpoints
@app.route('/api/categories', methods=['GET'])
def get_categories():
    """Get all categories"""
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT c.id, c.name, c.description, c.color, c.icon,
                   COUNT(s.id) as story_count
            FROM categories c
            LEFT JOIN stories s ON c.name = s.category
            GROUP BY c.id, c.name, c.description, c.color, c.icon
            ORDER BY c.name
        ''')
        
        rows = cursor.fetchall()
        categories = []
        
        for row in rows:
            categories.append({
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'color': row[3],
                'icon': row[4],
                'story_count': row[5]
            })
        
        conn.close()
        
        return jsonify({
            'success': True,
            'categories': categories,
            'count': len(categories)
        })
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# Sharing endpoints
@app.route('/api/stories/<int:story_id>/share', methods=['POST'])
def create_share_link(story_id):
    """Create shareable link"""
    try:
        data = request.get_json() or {}
        
        share_id = str(uuid.uuid4())
        sender_name = data.get('sender_name')
        personal_message = data.get('personal_message')
        expires_in_days = data.get('expires_in_days', 30)
        
        expires_at = datetime.utcnow() + timedelta(days=expires_in_days) if expires_in_days else None
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO sharing (share_id, story_id, sender_name, personal_message, expires_at)
            VALUES (?, ?, ?, ?, ?)
        ''', (share_id, story_id, sender_name, personal_message, expires_at))
        
        conn.commit()
        conn.close()
        
        base_url = os.environ.get('FRONTEND_URL', 'https://supportgrove.online')
        share_url = f"{base_url}/shared/{share_id}"
        
        return jsonify({
            'success': True,
            'share_data': {
                'share_id': share_id,
                'share_url': share_url,
                'expires_at': expires_at.isoformat() if expires_at else None
            }
        })
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/shared/<share_id>', methods=['GET'])
def get_shared_story(share_id):
    """Get shared story"""
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT s.share_id, s.sender_name, s.personal_message, s.expires_at, s.view_count,
                   st.id, st.title, st.content, st.category, st.hashtags, st.author_name,
                   st.created_at, st.reaction_hearts, st.reaction_hugs, st.reaction_sparkles,
                   st.comment_count
            FROM sharing s
            JOIN stories st ON s.story_id = st.id
            WHERE s.share_id = ?
        ''', (share_id,))
        
        row = cursor.fetchone()
        if not row:
            conn.close()
            return jsonify({'success': False, 'error': 'Shared story not found'}), 404
        
        # Check expiration
        if row[3]:
            expires_at = datetime.fromisoformat(row[3])
            if datetime.utcnow() > expires_at:
                conn.close()
                return jsonify({'success': False, 'error': 'Share link expired'}), 404
        
        # Increment view count
        cursor.execute('UPDATE sharing SET view_count = view_count + 1 WHERE share_id = ?', (share_id,))
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'data': {
                'share_info': {
                    'share_id': row[0],
                    'sender_name': row[1],
                    'personal_message': row[2],
                    'view_count': row[4] + 1
                },
                'story': {
                    'id': row[5],
                    'title': row[6],
                    'content': row[7],
                    'category': row[8],
                    'hashtags': json.loads(row[9]) if row[9] else [],
                    'author_name': row[10] or 'Anonymous',
                    'created_at': row[11],
                    'reactions': {
                        'hearts': row[12] or 0,
                        'hugs': row[13] or 0,
                        'sparkles': row[14] or 0
                    },
                    'comment_count': row[15] or 0
                }
            }
        })
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

# Initialize database on startup
init_database()

# Repository root entry point
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)

