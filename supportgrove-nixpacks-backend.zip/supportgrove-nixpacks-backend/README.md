# SupportGrove Backend - Nixpacks Optimized

This backend is specifically optimized for **Nixpacks** deployment on Railway.com, ensuring automatic detection and seamless deployment.

## 🚀 Nixpacks Optimization Features

### **✅ Automatic Detection**
- **requirements.txt** - Nixpacks automatically detects Python project
- **app.py** - Standard Flask entry point for automatic startup
- **runtime.txt** - Specifies Python 3.11 for consistent environment
- **Procfile** - Backup process definition for compatibility
- **nixpacks.toml** - Explicit Nixpacks configuration

### **✅ Zero Configuration Deployment**
1. **Push to GitHub** - Upload this folder to your repository
2. **Connect to Railway** - Railway automatically detects Python/Flask
3. **Nixpacks builds** - Automatically installs dependencies and configures
4. **Deploy instantly** - No manual configuration needed

## 📁 Nixpacks-Optimized Structure

```
supportgrove-nixpacks-backend/
├── app.py              # Main Flask application (Nixpacks entry point)
├── requirements.txt    # Python dependencies (Nixpacks detection)
├── nixpacks.toml      # Explicit Nixpacks configuration
├── Procfile           # Process definition (backup compatibility)
├── runtime.txt        # Python version specification
├── .env.example       # Environment variables template
└── README.md          # This deployment guide
```

## 🔧 Nixpacks Configuration Details

### **nixpacks.toml**
```toml
[phases.setup]
nixPkgs = ["python3", "pip"]

[phases.install]
cmds = ["pip install -r requirements.txt"]

[start]
cmd = "python app.py"
```

### **requirements.txt**
```
Flask==3.0.0
Flask-CORS==4.0.0
Werkzeug==3.0.1
gunicorn==21.2.0
```

### **runtime.txt**
```
python-3.11
```

## ✨ Complete SupportGrove Features

### **🏠 Core Platform**
- Anonymous story sharing with guided questions
- Six support categories with inclusive descriptions
- Story reactions (hearts, hugs, sparkles)
- Threaded commenting system
- Real-time notifications

### **📤 Forwarding System**
- Generate shareable links for stories
- Email forwarding with beautiful templates
- Personal messages and sender attribution
- Link expiration and view tracking

### **🌍 Inclusive Trauma Category**
Updated with comprehensive examples:
- Racial trauma
- Sexism and gender-based discrimination
- Religious abuse
- Gender fluidity shaming
- Multigenerational family dysfunctionality

### **🛡️ Privacy & Safety**
- Anonymous user sessions
- Content sanitization and validation
- Pseudonym support for consistency
- Privacy reminders built into the interface

## 🚀 Railway Deployment Steps

### **1. Upload to GitHub**
```bash
# Add this backend folder to your repository
git add supportgrove-nixpacks-backend/
git commit -m "Add Nixpacks-optimized SupportGrove backend"
git push origin main
```

### **2. Deploy to Railway**
1. Go to [railway.app/new](https://railway.app/new)
2. Click "Deploy from GitHub repo"
3. Select your repository
4. **Set root directory**: `supportgrove-nixpacks-backend`
5. **Nixpacks automatically detects and deploys!**

### **3. Environment Variables**
Set in Railway dashboard:
- `SECRET_KEY` - Your Flask secret key
- `CORS_ORIGINS` - Your frontend URL (e.g., `https://supportgrove.online`)
- `FRONTEND_URL` - Your frontend URL for share links
- `SMTP_USERNAME` - Email for forwarding (optional)
- `SMTP_PASSWORD` - Email password (optional)

### **4. Custom Domain**
- Add `api.supportgrove.online` in Railway project settings
- Update DNS records as instructed by Railway
- SSL certificate automatically provisioned

## 🎯 Nixpacks Advantages

### **✅ Perfect Detection**
- **Automatic Python detection** from requirements.txt
- **Flask framework recognition** from app.py structure
- **Dependency installation** via pip automatically
- **Process management** with proper startup commands

### **✅ Optimized Build Process**
- **Fast builds** with Nixpacks caching
- **Minimal container size** with only necessary dependencies
- **Consistent environment** across deployments
- **Automatic scaling** based on traffic

### **✅ Production Ready**
- **Health check endpoint** at `/health` and `/api/health`
- **Error handling** with proper HTTP status codes
- **CORS configuration** for frontend integration
- **Database persistence** with SQLite

## 📡 API Endpoints

### **Health & Status**
- `GET /health` - Health check for Railway
- `GET /api/health` - Detailed health status
- `GET /` - API information and endpoints

### **Stories**
- `GET /api/stories` - Get stories (with category filter)
- `POST /api/stories` - Create new story
- `POST /api/stories/{id}/reactions` - Add/remove reactions

### **Comments**
- `GET /api/stories/{id}/comments` - Get story comments
- `POST /api/stories/{id}/comments` - Create comment

### **Categories**
- `GET /api/categories` - Get all categories with story counts

### **Sharing/Forwarding**
- `POST /api/stories/{id}/share` - Create shareable link
- `GET /api/shared/{share_id}` - Get shared story

## 🔍 Nixpacks Build Process

When you deploy, Nixpacks automatically:

1. **Detects Python** from requirements.txt
2. **Installs Python 3.11** as specified in runtime.txt
3. **Installs dependencies** with `pip install -r requirements.txt`
4. **Configures environment** with proper Python paths
5. **Starts application** with `python app.py`
6. **Exposes health check** for Railway monitoring

## 🛠️ Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Set environment variables
cp .env.example .env
# Edit .env with your values

# Run the application
python app.py
```

API available at `http://localhost:5000`

## 🔧 Troubleshooting

### **Common Nixpacks Issues**

1. **Build Fails**:
   - Check requirements.txt for valid package versions
   - Verify Python version in runtime.txt
   - Review nixpacks.toml configuration

2. **App Won't Start**:
   - Ensure app.py has `if __name__ == '__main__':` block
   - Check PORT environment variable usage
   - Verify Flask app is bound to `0.0.0.0`

3. **Database Issues**:
   - SQLite is automatically supported on Railway
   - Database file persists across deployments
   - Check file permissions and paths

### **Nixpacks Debugging**
- View build logs in Railway dashboard
- Check environment variables are set correctly
- Use `/health` endpoint to verify deployment
- Review Railway service logs for runtime errors

## 🌟 Why This Backend is Nixpacks-Perfect

### **✅ Follows Nixpacks Best Practices**
- **Standard file structure** that Nixpacks recognizes
- **Minimal dependencies** for faster builds
- **Explicit configuration** with nixpacks.toml
- **Health checks** for proper monitoring

### **✅ Railway Integration**
- **Automatic HTTPS** with custom domains
- **Environment variable** management
- **Persistent storage** for SQLite database
- **Scaling capabilities** as your community grows

### **✅ Production Optimized**
- **Error handling** with proper HTTP responses
- **Content validation** and sanitization
- **CORS configuration** for frontend integration
- **Database initialization** on first startup

Your SupportGrove backend is now **perfectly optimized for Nixpacks** and will deploy seamlessly on Railway! 🚀

