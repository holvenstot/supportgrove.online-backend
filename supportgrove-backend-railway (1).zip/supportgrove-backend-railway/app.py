#!/usr/bin/env python3
"""
SupportGrove Backend - Production Flask Application
Optimized for Railway.com deployment
"""

import os
import sys
from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime, timedelta
import sqlite3
import uuid
import smtplib
from email.mime.text import MimeText
from email.mime.multipart import MimeMultipart
import logging

# Add src directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Import application modules
from models.story import Story
from models.comment import Comment
from models.user import User
from models.sharing import Sharing
from routes.stories import stories_bp
from routes.comments import comments_bp
from routes.categories import categories_bp
from routes.notifications import notifications_bp
from routes.sharing import sharing_bp

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_app():
    """Create and configure the Flask application"""
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    app.config['DATABASE_URL'] = os.environ.get('DATABASE_URL', 'sqlite:///supportgrove.db')
    app.config['CORS_ORIGINS'] = os.environ.get('CORS_ORIGINS', '*')
    
    # Email configuration for forwarding feature
    app.config['SMTP_SERVER'] = os.environ.get('SMTP_SERVER', 'smtp.gmail.com')
    app.config['SMTP_PORT'] = int(os.environ.get('SMTP_PORT', '587'))
    app.config['SMTP_USERNAME'] = os.environ.get('SMTP_USERNAME', '')
    app.config['SMTP_PASSWORD'] = os.environ.get('SMTP_PASSWORD', '')
    
    # Enable CORS for all routes
    CORS(app, origins=app.config['CORS_ORIGINS'])
    
    # Initialize database
    init_database()
    
    # Register blueprints
    app.register_blueprint(stories_bp, url_prefix='/api')
    app.register_blueprint(comments_bp, url_prefix='/api')
    app.register_blueprint(categories_bp, url_prefix='/api')
    app.register_blueprint(notifications_bp, url_prefix='/api')
    app.register_blueprint(sharing_bp, url_prefix='/api')
    
    # Health check endpoint for Railway
    @app.route('/api/health')
    def health_check():
        """Health check endpoint for Railway deployment"""
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'version': '1.0.0'
        })
    
    # Root endpoint
    @app.route('/')
    def root():
        """Root endpoint"""
        return jsonify({
            'message': 'SupportGrove API is running',
            'version': '1.0.0',
            'endpoints': {
                'health': '/api/health',
                'stories': '/api/stories',
                'comments': '/api/comments',
                'categories': '/api/categories',
                'notifications': '/api/notifications',
                'sharing': '/api/sharing'
            }
        })
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({'error': 'Not found'}), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        logger.error(f"Internal server error: {error}")
        return jsonify({'error': 'Internal server error'}), 500
    
    return app

def init_database():
    """Initialize the SQLite database with all required tables"""
    db_path = 'supportgrove.db'
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create stories table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS stories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                category TEXT NOT NULL,
                hashtags TEXT,
                author_name TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                reaction_hearts INTEGER DEFAULT 0,
                reaction_hugs INTEGER DEFAULT 0,
                reaction_sparkles INTEGER DEFAULT 0,
                comment_count INTEGER DEFAULT 0
            )
        ''')
        
        # Create comments table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                story_id INTEGER NOT NULL,
                parent_id INTEGER,
                content TEXT NOT NULL,
                author_name TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (story_id) REFERENCES stories (id),
                FOREIGN KEY (parent_id) REFERENCES comments (id)
            )
        ''')
        
        # Create categories table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                description TEXT NOT NULL,
                color TEXT NOT NULL,
                icon TEXT NOT NULL,
                story_count INTEGER DEFAULT 0
            )
        ''')
        
        # Create sharing table for forwarding feature
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sharing (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                share_id TEXT NOT NULL UNIQUE,
                story_id INTEGER NOT NULL,
                sender_name TEXT,
                personal_message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                view_count INTEGER DEFAULT 0,
                FOREIGN KEY (story_id) REFERENCES stories (id)
            )
        ''')
        
        # Create notifications table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                story_id INTEGER,
                comment_id INTEGER,
                type TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                read_at TIMESTAMP,
                FOREIGN KEY (story_id) REFERENCES stories (id),
                FOREIGN KEY (comment_id) REFERENCES comments (id)
            )
        ''')
        
        conn.commit()
        logger.info("Database initialized successfully")
        
        # Seed categories if they don't exist
        cursor.execute("SELECT COUNT(*) FROM categories")
        if cursor.fetchone()[0] == 0:
            seed_categories(cursor)
            conn.commit()
            logger.info("Categories seeded successfully")
        
        conn.close()
        
    except Exception as e:
        logger.error(f"Database initialization error: {e}")
        raise

def seed_categories(cursor):
    """Seed the database with initial categories"""
    categories = [
        {
            'name': 'Depression & Anxiety',
            'description': 'Experiences with depression, anxiety disorders, panic attacks, and mood-related challenges',
            'color': 'blue',
            'icon': 'cloud-rain'
        },
        {
            'name': 'Trauma & Healing',
            'description': 'Experiences with PTSD, childhood trauma, abuse recovery, racial trauma, sexism, religious abuse, gender fluidity shaming, and multigenerational family dysfunctionality',
            'color': 'purple',
            'icon': 'heart'
        },
        {
            'name': 'Addiction & Recovery',
            'description': 'Stories of addiction, substance abuse recovery, behavioral addictions, and sobriety journeys',
            'color': 'green',
            'icon': 'refresh-cw'
        },
        {
            'name': 'Relationships & Family',
            'description': 'Challenges with family dynamics, romantic relationships, friendships, and social connections',
            'color': 'pink',
            'icon': 'users'
        },
        {
            'name': 'Work & Life Balance',
            'description': 'Workplace stress, burnout, career transitions, and finding balance in daily life',
            'color': 'orange',
            'icon': 'briefcase'
        },
        {
            'name': 'Identity & Self-Worth',
            'description': 'Self-esteem issues, identity exploration, body image, and personal growth journeys',
            'color': 'teal',
            'icon': 'user'
        }
    ]
    
    for category in categories:
        cursor.execute('''
            INSERT INTO categories (name, description, color, icon)
            VALUES (?, ?, ?, ?)
        ''', (category['name'], category['description'], category['color'], category['icon']))

# Create the Flask application
app = create_app()

if __name__ == '__main__':
    # Railway sets the PORT environment variable
    port = int(os.environ.get('PORT', 5000))
    
    # Railway requires binding to 0.0.0.0
    app.run(
        host='0.0.0.0',
        port=port,
        debug=False,  # Always False in production
        threaded=True
    )

