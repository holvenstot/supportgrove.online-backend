"""
Categories routes for SupportGrove API
Handles category-related endpoints
"""

from flask import Blueprint, request, jsonify
import sqlite3

categories_bp = Blueprint('categories', __name__)

@categories_bp.route('/categories', methods=['GET'])
def get_categories():
    """Get all categories with story counts"""
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT c.id, c.name, c.description, c.color, c.icon,
                   COUNT(s.id) as story_count
            FROM categories c
            LEFT JOIN stories s ON c.name = s.category
            GROUP BY c.id, c.name, c.description, c.color, c.icon
            ORDER BY c.name
        ''')
        
        rows = cursor.fetchall()
        categories = []
        
        for row in rows:
            categories.append({
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'color': row[3],
                'icon': row[4],
                'story_count': row[5]
            })
        
        conn.close()
        
        return jsonify({
            'success': True,
            'categories': categories,
            'count': len(categories)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@categories_bp.route('/categories/<int:category_id>', methods=['GET'])
def get_category(category_id):
    """Get a specific category by ID"""
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT c.id, c.name, c.description, c.color, c.icon,
                   COUNT(s.id) as story_count
            FROM categories c
            LEFT JOIN stories s ON c.name = s.category
            WHERE c.id = ?
            GROUP BY c.id, c.name, c.description, c.color, c.icon
        ''', (category_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return jsonify({
                'success': False,
                'error': 'Category not found'
            }), 404
        
        category = {
            'id': row[0],
            'name': row[1],
            'description': row[2],
            'color': row[3],
            'icon': row[4],
            'story_count': row[5]
        }
        
        return jsonify({
            'success': True,
            'category': category
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@categories_bp.route('/categories/seed', methods=['POST'])
def seed_categories():
    """Seed the database with initial categories (admin function)"""
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        # Check if categories already exist
        cursor.execute('SELECT COUNT(*) FROM categories')
        count = cursor.fetchone()[0]
        
        if count > 0:
            conn.close()
            return jsonify({
                'success': True,
                'message': 'Categories already exist',
                'count': count
            })
        
        # Seed categories with updated trauma description
        categories = [
            {
                'name': 'Depression & Anxiety',
                'description': 'Experiences with depression, anxiety disorders, panic attacks, and mood-related challenges',
                'color': 'blue',
                'icon': 'cloud-rain'
            },
            {
                'name': 'Trauma & Healing',
                'description': 'Experiences with PTSD, childhood trauma, abuse recovery, racial trauma, sexism, religious abuse, gender fluidity shaming, and multigenerational family dysfunctionality',
                'color': 'purple',
                'icon': 'heart'
            },
            {
                'name': 'Addiction & Recovery',
                'description': 'Stories of addiction, substance abuse recovery, behavioral addictions, and sobriety journeys',
                'color': 'green',
                'icon': 'refresh-cw'
            },
            {
                'name': 'Relationships & Family',
                'description': 'Challenges with family dynamics, romantic relationships, friendships, and social connections',
                'color': 'pink',
                'icon': 'users'
            },
            {
                'name': 'Work & Life Balance',
                'description': 'Workplace stress, burnout, career transitions, and finding balance in daily life',
                'color': 'orange',
                'icon': 'briefcase'
            },
            {
                'name': 'Identity & Self-Worth',
                'description': 'Self-esteem issues, identity exploration, body image, and personal growth journeys',
                'color': 'teal',
                'icon': 'user'
            }
        ]
        
        for category in categories:
            cursor.execute('''
                INSERT INTO categories (name, description, color, icon)
                VALUES (?, ?, ?, ?)
            ''', (category['name'], category['description'], category['color'], category['icon']))
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': 'Categories seeded successfully',
            'count': len(categories)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@categories_bp.route('/categories/stats', methods=['GET'])
def get_category_stats():
    """Get category statistics"""
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT 
                c.name,
                COUNT(s.id) as story_count,
                COALESCE(SUM(s.reaction_hearts), 0) as total_hearts,
                COALESCE(SUM(s.reaction_hugs), 0) as total_hugs,
                COALESCE(SUM(s.reaction_sparkles), 0) as total_sparkles,
                COALESCE(SUM(s.comment_count), 0) as total_comments
            FROM categories c
            LEFT JOIN stories s ON c.name = s.category
            GROUP BY c.id, c.name
            ORDER BY story_count DESC
        ''')
        
        rows = cursor.fetchall()
        stats = []
        
        for row in rows:
            stats.append({
                'category': row[0],
                'story_count': row[1],
                'total_reactions': row[2] + row[3] + row[4],
                'total_hearts': row[2],
                'total_hugs': row[3],
                'total_sparkles': row[4],
                'total_comments': row[5]
            })
        
        conn.close()
        
        return jsonify({
            'success': True,
            'stats': stats
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

