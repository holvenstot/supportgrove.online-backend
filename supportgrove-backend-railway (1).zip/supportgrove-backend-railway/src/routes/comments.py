"""
Comments routes for SupportGrove API
Handles comment-related endpoints
"""

from flask import Blueprint, request, jsonify
from models.comment import Comment
from models.user import User

comments_bp = Blueprint('comments', __name__)

@comments_bp.route('/stories/<int:story_id>/comments', methods=['GET'])
def get_comments(story_id):
    """Get all comments for a story"""
    try:
        comment_model = Comment()
        comments = comment_model.get_comments_by_story(story_id)
        
        return jsonify({
            'success': True,
            'comments': comments,
            'count': len(comments)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@comments_bp.route('/stories/<int:story_id>/comments', methods=['POST'])
def create_comment(story_id):
    """Create a new comment on a story"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        if not data.get('content'):
            return jsonify({
                'success': False,
                'error': 'Comment content is required'
            }), 400
        
        # Validate and sanitize input
        user_model = User()
        
        content = user_model.sanitize_content(data['content'])
        author_name = data.get('author_name')
        parent_id = data.get('parent_id')
        
        if author_name:
            is_valid, author_name = user_model.validate_pseudonym(author_name)
            if not is_valid:
                return jsonify({
                    'success': False,
                    'error': f'Invalid author name: {author_name}'
                }), 400
        
        # Create comment
        comment_model = Comment()
        comment = comment_model.create_comment(
            story_id=story_id,
            content=content,
            author_name=author_name,
            parent_id=parent_id
        )
        
        return jsonify({
            'success': True,
            'comment': comment,
            'message': 'Comment created successfully'
        }), 201
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@comments_bp.route('/comments/<int:comment_id>', methods=['GET'])
def get_comment(comment_id):
    """Get a specific comment by ID"""
    try:
        comment_model = Comment()
        comment = comment_model.get_comment(comment_id)
        
        if not comment:
            return jsonify({
                'success': False,
                'error': 'Comment not found'
            }), 404
        
        return jsonify({
            'success': True,
            'comment': comment
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@comments_bp.route('/comments/<int:comment_id>', methods=['DELETE'])
def delete_comment(comment_id):
    """Delete a comment (admin function)"""
    try:
        comment_model = Comment()
        success = comment_model.delete_comment(comment_id)
        
        if not success:
            return jsonify({
                'success': False,
                'error': 'Comment not found'
            }), 404
        
        return jsonify({
            'success': True,
            'message': 'Comment deleted successfully'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@comments_bp.route('/comments/<int:comment_id>/reply', methods=['POST'])
def reply_to_comment(comment_id):
    """Reply to a specific comment"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        if not data.get('content'):
            return jsonify({
                'success': False,
                'error': 'Reply content is required'
            }), 400
        
        # Get the parent comment to find the story_id
        comment_model = Comment()
        parent_comment = comment_model.get_comment(comment_id)
        
        if not parent_comment:
            return jsonify({
                'success': False,
                'error': 'Parent comment not found'
            }), 404
        
        # Validate and sanitize input
        user_model = User()
        
        content = user_model.sanitize_content(data['content'])
        author_name = data.get('author_name')
        
        if author_name:
            is_valid, author_name = user_model.validate_pseudonym(author_name)
            if not is_valid:
                return jsonify({
                    'success': False,
                    'error': f'Invalid author name: {author_name}'
                }), 400
        
        # Create reply
        reply = comment_model.create_comment(
            story_id=parent_comment['story_id'],
            content=content,
            author_name=author_name,
            parent_id=comment_id
        )
        
        return jsonify({
            'success': True,
            'comment': reply,
            'message': 'Reply created successfully'
        }), 201
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

