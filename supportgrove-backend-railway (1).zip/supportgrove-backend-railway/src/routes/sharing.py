"""
Sharing routes for SupportGrove API
Handles story forwarding and sharing functionality
"""

from flask import Blueprint, request, jsonify
from models.sharing import Sharing
import re

sharing_bp = Blueprint('sharing', __name__)

@sharing_bp.route('/stories/<int:story_id>/share', methods=['POST'])
def create_share_link(story_id):
    """Create a shareable link for a story"""
    try:
        data = request.get_json() or {}
        
        sender_name = data.get('sender_name')
        personal_message = data.get('personal_message')
        expires_in_days = data.get('expires_in_days', 30)
        
        # Validate sender name if provided
        if sender_name and len(sender_name.strip()) > 50:
            return jsonify({
                'success': False,
                'error': 'Sender name must be 50 characters or less'
            }), 400
        
        # Validate personal message if provided
        if personal_message and len(personal_message.strip()) > 500:
            return jsonify({
                'success': False,
                'error': 'Personal message must be 500 characters or less'
            }), 400
        
        sharing_model = Sharing()
        share_data = sharing_model.create_share_link(
            story_id=story_id,
            sender_name=sender_name,
            personal_message=personal_message,
            expires_in_days=expires_in_days
        )
        
        return jsonify({
            'success': True,
            'share_data': share_data,
            'message': 'Share link created successfully'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@sharing_bp.route('/shared/<share_id>', methods=['GET'])
def get_shared_story(share_id):
    """Get a story by share ID"""
    try:
        sharing_model = Sharing()
        shared_data = sharing_model.get_shared_story(share_id)
        
        if not shared_data:
            return jsonify({
                'success': False,
                'error': 'Shared story not found or expired'
            }), 404
        
        return jsonify({
            'success': True,
            'data': shared_data
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@sharing_bp.route('/stories/<int:story_id>/email', methods=['POST'])
def send_story_email(story_id):
    """Send a story via email"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        recipient_email = data.get('recipient_email')
        if not recipient_email:
            return jsonify({
                'success': False,
                'error': 'Recipient email is required'
            }), 400
        
        # Validate email format
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_pattern, recipient_email):
            return jsonify({
                'success': False,
                'error': 'Invalid email format'
            }), 400
        
        sender_name = data.get('sender_name')
        personal_message = data.get('personal_message')
        
        # Validate sender name if provided
        if sender_name and len(sender_name.strip()) > 50:
            return jsonify({
                'success': False,
                'error': 'Sender name must be 50 characters or less'
            }), 400
        
        # Validate personal message if provided
        if personal_message and len(personal_message.strip()) > 500:
            return jsonify({
                'success': False,
                'error': 'Personal message must be 500 characters or less'
            }), 400
        
        sharing_model = Sharing()
        result = sharing_model.send_story_email(
            story_id=story_id,
            recipient_email=recipient_email,
            sender_name=sender_name,
            personal_message=personal_message
        )
        
        if result['success']:
            return jsonify({
                'success': True,
                'message': result['message'],
                'share_url': result['share_url']
            })
        else:
            return jsonify({
                'success': False,
                'error': result['message']
            }), 500
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@sharing_bp.route('/shared/<share_id>/stats', methods=['GET'])
def get_share_stats(share_id):
    """Get sharing statistics"""
    try:
        sharing_model = Sharing()
        stats = sharing_model.get_share_stats(share_id)
        
        if not stats:
            return jsonify({
                'success': False,
                'error': 'Share not found'
            }), 404
        
        return jsonify({
            'success': True,
            'stats': stats
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@sharing_bp.route('/sharing/validate-email', methods=['POST'])
def validate_email():
    """Validate email address format"""
    try:
        data = request.get_json()
        
        if not data or 'email' not in data:
            return jsonify({
                'success': False,
                'error': 'Email is required'
            }), 400
        
        email = data['email'].strip()
        
        # Validate email format
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        is_valid = bool(re.match(email_pattern, email))
        
        return jsonify({
            'success': True,
            'is_valid': is_valid,
            'email': email
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

