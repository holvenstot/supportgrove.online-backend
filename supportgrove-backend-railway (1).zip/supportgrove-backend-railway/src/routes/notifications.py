"""
Notifications routes for SupportGrove API
Handles notification-related endpoints
"""

from flask import Blueprint, request, jsonify
import sqlite3
from datetime import datetime

notifications_bp = Blueprint('notifications', __name__)

@notifications_bp.route('/notifications', methods=['GET'])
def get_notifications():
    """Get recent notifications"""
    try:
        limit = int(request.args.get('limit', 20))
        offset = int(request.args.get('offset', 0))
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT n.id, n.story_id, n.comment_id, n.type, n.message, 
                   n.created_at, n.read_at,
                   s.title as story_title
            FROM notifications n
            LEFT JOIN stories s ON n.story_id = s.id
            ORDER BY n.created_at DESC
            LIMIT ? OFFSET ?
        ''', (limit, offset))
        
        rows = cursor.fetchall()
        notifications = []
        
        for row in rows:
            notifications.append({
                'id': row[0],
                'story_id': row[1],
                'comment_id': row[2],
                'type': row[3],
                'message': row[4],
                'created_at': row[5],
                'read_at': row[6],
                'story_title': row[7],
                'is_read': row[6] is not None
            })
        
        conn.close()
        
        return jsonify({
            'success': True,
            'notifications': notifications,
            'count': len(notifications)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@notifications_bp.route('/notifications', methods=['POST'])
def create_notification():
    """Create a new notification"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        required_fields = ['type', 'message']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO notifications (story_id, comment_id, type, message)
            VALUES (?, ?, ?, ?)
        ''', (
            data.get('story_id'),
            data.get('comment_id'),
            data['type'],
            data['message']
        ))
        
        notification_id = cursor.lastrowid
        conn.commit()
        
        # Get the created notification
        cursor.execute('''
            SELECT id, story_id, comment_id, type, message, created_at, read_at
            FROM notifications WHERE id = ?
        ''', (notification_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        notification = {
            'id': row[0],
            'story_id': row[1],
            'comment_id': row[2],
            'type': row[3],
            'message': row[4],
            'created_at': row[5],
            'read_at': row[6],
            'is_read': row[6] is not None
        }
        
        return jsonify({
            'success': True,
            'notification': notification,
            'message': 'Notification created successfully'
        }), 201
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@notifications_bp.route('/notifications/<int:notification_id>/read', methods=['POST'])
def mark_notification_read(notification_id):
    """Mark a notification as read"""
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE notifications 
            SET read_at = CURRENT_TIMESTAMP
            WHERE id = ? AND read_at IS NULL
        ''', (notification_id,))
        
        if cursor.rowcount == 0:
            conn.close()
            return jsonify({
                'success': False,
                'error': 'Notification not found or already read'
            }), 404
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': 'Notification marked as read'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@notifications_bp.route('/notifications/unread-count', methods=['GET'])
def get_unread_count():
    """Get count of unread notifications"""
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT COUNT(*) FROM notifications WHERE read_at IS NULL
        ''')
        
        count = cursor.fetchone()[0]
        conn.close()
        
        return jsonify({
            'success': True,
            'unread_count': count
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@notifications_bp.route('/notifications/mark-all-read', methods=['POST'])
def mark_all_read():
    """Mark all notifications as read"""
    try:
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE notifications 
            SET read_at = CURRENT_TIMESTAMP
            WHERE read_at IS NULL
        ''')
        
        updated_count = cursor.rowcount
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': f'Marked {updated_count} notifications as read'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@notifications_bp.route('/notifications/cleanup', methods=['POST'])
def cleanup_old_notifications():
    """Clean up old notifications (admin function)"""
    try:
        days = int(request.args.get('days', 30))
        
        conn = sqlite3.connect('supportgrove.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            DELETE FROM notifications 
            WHERE created_at < datetime('now', '-' || ? || ' days')
        ''', (days,))
        
        deleted_count = cursor.rowcount
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': f'Deleted {deleted_count} old notifications'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

