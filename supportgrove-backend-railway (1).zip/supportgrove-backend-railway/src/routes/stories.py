"""
Stories routes for SupportGrove API
Handles story-related endpoints
"""

from flask import Blueprint, request, jsonify
from models.story import Story
from models.user import User
import json

stories_bp = Blueprint('stories', __name__)

@stories_bp.route('/stories', methods=['GET'])
def get_stories():
    """Get stories with optional category filter"""
    try:
        category = request.args.get('category')
        limit = int(request.args.get('limit', 20))
        offset = int(request.args.get('offset', 0))
        
        story_model = Story()
        stories = story_model.get_stories(category=category, limit=limit, offset=offset)
        
        return jsonify({
            'success': True,
            'stories': stories,
            'count': len(stories)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@stories_bp.route('/stories/<int:story_id>', methods=['GET'])
def get_story(story_id):
    """Get a specific story by ID"""
    try:
        story_model = Story()
        story = story_model.get_story(story_id)
        
        if not story:
            return jsonify({
                'success': False,
                'error': 'Story not found'
            }), 404
        
        return jsonify({
            'success': True,
            'story': story
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@stories_bp.route('/stories', methods=['POST'])
def create_story():
    """Create a new story"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        required_fields = ['title', 'content', 'category']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Validate and sanitize input
        user_model = User()
        
        title = user_model.sanitize_content(data['title'])
        content = user_model.sanitize_content(data['content'])
        category = data['category']
        hashtags = data.get('hashtags', [])
        author_name = data.get('author_name')
        
        if author_name:
            is_valid, author_name = user_model.validate_pseudonym(author_name)
            if not is_valid:
                return jsonify({
                    'success': False,
                    'error': f'Invalid author name: {author_name}'
                }), 400
        
        # Create story
        story_model = Story()
        story = story_model.create_story(
            title=title,
            content=content,
            category=category,
            hashtags=hashtags,
            author_name=author_name
        )
        
        return jsonify({
            'success': True,
            'story': story,
            'message': 'Story created successfully'
        }), 201
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@stories_bp.route('/stories/<int:story_id>/reactions', methods=['POST'])
def add_reaction():
    """Add or remove a reaction to a story"""
    try:
        story_id = int(request.view_args['story_id'])
        data = request.get_json()
        
        if not data or 'type' not in data:
            return jsonify({
                'success': False,
                'error': 'Reaction type is required'
            }), 400
        
        reaction_type = data['type']
        increment = data.get('increment', True)
        
        # Validate reaction type
        valid_reactions = ['hearts', 'hugs', 'sparkles']
        if reaction_type not in valid_reactions:
            return jsonify({
                'success': False,
                'error': f'Invalid reaction type. Must be one of: {valid_reactions}'
            }), 400
        
        story_model = Story()
        story = story_model.update_reaction(story_id, reaction_type, increment)
        
        if not story:
            return jsonify({
                'success': False,
                'error': 'Story not found'
            }), 404
        
        return jsonify({
            'success': True,
            'story': story,
            'message': f'Reaction {reaction_type} {"added" if increment else "removed"}'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@stories_bp.route('/stories/<int:story_id>', methods=['DELETE'])
def delete_story(story_id):
    """Delete a story (admin function)"""
    try:
        story_model = Story()
        success = story_model.delete_story(story_id)
        
        if not success:
            return jsonify({
                'success': False,
                'error': 'Story not found'
            }), 404
        
        return jsonify({
            'success': True,
            'message': 'Story deleted successfully'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@stories_bp.route('/stories/search', methods=['GET'])
def search_stories():
    """Search stories by keyword"""
    try:
        query = request.args.get('q', '').strip()
        category = request.args.get('category')
        limit = int(request.args.get('limit', 20))
        
        if not query:
            return jsonify({
                'success': False,
                'error': 'Search query is required'
            }), 400
        
        # For now, return empty results
        # This could be implemented with full-text search
        return jsonify({
            'success': True,
            'stories': [],
            'count': 0,
            'query': query
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

