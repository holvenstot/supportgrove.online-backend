"""
User model for SupportGrove
Handles anonymous user sessions and preferences
"""

import sqlite3
import uuid
from datetime import datetime

class User:
    def __init__(self, db_path='supportgrove.db'):
        self.db_path = db_path
    
    def create_anonymous_session(self, pseudonym=None):
        """Create an anonymous user session"""
        session_id = str(uuid.uuid4())
        
        return {
            'session_id': session_id,
            'pseudonym': pseudonym or 'Anonymous',
            'created_at': datetime.utcnow().isoformat(),
            'is_anonymous': True
        }
    
    def validate_pseudonym(self, pseudonym):
        """Validate pseudonym for appropriateness"""
        if not pseudonym:
            return True, "Anonymous"
        
        # Basic validation rules
        pseudonym = pseudonym.strip()
        
        if len(pseudonym) > 50:
            return False, "Pseudonym must be 50 characters or less"
        
        if len(pseudonym) < 2:
            return False, "Pseudonym must be at least 2 characters"
        
        # Check for inappropriate content (basic filter)
        inappropriate_words = [
            'admin', 'moderator', 'support', 'official',
            'fuck', 'shit', 'damn', 'hell'  # Add more as needed
        ]
        
        pseudonym_lower = pseudonym.lower()
        for word in inappropriate_words:
            if word in pseudonym_lower:
                return False, f"Pseudonym contains inappropriate content"
        
        return True, pseudonym
    
    def get_user_activity(self, session_id):
        """Get user activity summary (stories, comments posted)"""
        # For anonymous users, we don't track detailed activity
        # This could be expanded for registered users in the future
        return {
            'session_id': session_id,
            'stories_posted': 0,
            'comments_posted': 0,
            'reactions_given': 0
        }
    
    def sanitize_content(self, content):
        """Basic content sanitization"""
        if not content:
            return ""
        
        # Remove potential HTML/script tags
        import re
        content = re.sub(r'<[^>]+>', '', content)
        
        # Limit length
        if len(content) > 10000:
            content = content[:10000] + "..."
        
        return content.strip()
    
    def check_rate_limit(self, session_id, action_type='post'):
        """Check if user has exceeded rate limits"""
        # For now, return True (no rate limiting)
        # This could be implemented with Redis or database tracking
        return True, "OK"
    
    def log_user_action(self, session_id, action_type, content_id=None):
        """Log user action for analytics/moderation"""
        # For anonymous users, we keep minimal logging
        # This could be expanded for abuse prevention
        pass

