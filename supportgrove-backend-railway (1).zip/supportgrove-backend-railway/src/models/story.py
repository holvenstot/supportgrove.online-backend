"""
Story model for SupportGrove
Handles story data and database operations
"""

import sqlite3
import json
from datetime import datetime
import uuid

class Story:
    def __init__(self, db_path='supportgrove.db'):
        self.db_path = db_path
    
    def create_story(self, title, content, category, hashtags=None, author_name=None):
        """Create a new story"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            hashtags_str = json.dumps(hashtags) if hashtags else None
            
            cursor.execute('''
                INSERT INTO stories (title, content, category, hashtags, author_name)
                VALUES (?, ?, ?, ?, ?)
            ''', (title, content, category, hashtags_str, author_name))
            
            story_id = cursor.lastrowid
            conn.commit()
            
            return self.get_story(story_id)
        
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def get_story(self, story_id):
        """Get a story by ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT id, title, content, category, hashtags, author_name,
                       created_at, updated_at, reaction_hearts, reaction_hugs,
                       reaction_sparkles, comment_count
                FROM stories WHERE id = ?
            ''', (story_id,))
            
            row = cursor.fetchone()
            if row:
                return self._row_to_dict(row)
            return None
        
        finally:
            conn.close()
    
    def get_stories(self, category=None, limit=20, offset=0):
        """Get stories with optional category filter"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            if category:
                cursor.execute('''
                    SELECT id, title, content, category, hashtags, author_name,
                           created_at, updated_at, reaction_hearts, reaction_hugs,
                           reaction_sparkles, comment_count
                    FROM stories WHERE category = ?
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                ''', (category, limit, offset))
            else:
                cursor.execute('''
                    SELECT id, title, content, category, hashtags, author_name,
                           created_at, updated_at, reaction_hearts, reaction_hugs,
                           reaction_sparkles, comment_count
                    FROM stories
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                ''', (limit, offset))
            
            rows = cursor.fetchall()
            return [self._row_to_dict(row) for row in rows]
        
        finally:
            conn.close()
    
    def update_reaction(self, story_id, reaction_type, increment=True):
        """Update reaction count for a story"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            column_map = {
                'hearts': 'reaction_hearts',
                'hugs': 'reaction_hugs',
                'sparkles': 'reaction_sparkles'
            }
            
            column = column_map.get(reaction_type)
            if not column:
                raise ValueError(f"Invalid reaction type: {reaction_type}")
            
            operation = '+' if increment else '-'
            cursor.execute(f'''
                UPDATE stories 
                SET {column} = MAX(0, {column} {operation} 1)
                WHERE id = ?
            ''', (story_id,))
            
            conn.commit()
            return self.get_story(story_id)
        
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def update_comment_count(self, story_id):
        """Update comment count for a story"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                UPDATE stories 
                SET comment_count = (
                    SELECT COUNT(*) FROM comments WHERE story_id = ?
                )
                WHERE id = ?
            ''', (story_id, story_id))
            
            conn.commit()
        
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def delete_story(self, story_id):
        """Delete a story and its associated comments"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Delete comments first (foreign key constraint)
            cursor.execute('DELETE FROM comments WHERE story_id = ?', (story_id,))
            
            # Delete the story
            cursor.execute('DELETE FROM stories WHERE id = ?', (story_id,))
            
            conn.commit()
            return cursor.rowcount > 0
        
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def _row_to_dict(self, row):
        """Convert database row to dictionary"""
        return {
            'id': row[0],
            'title': row[1],
            'content': row[2],
            'category': row[3],
            'hashtags': json.loads(row[4]) if row[4] else [],
            'author_name': row[5] or 'Anonymous',
            'created_at': row[6],
            'updated_at': row[7],
            'reactions': {
                'hearts': row[8] or 0,
                'hugs': row[9] or 0,
                'sparkles': row[10] or 0
            },
            'comment_count': row[11] or 0
        }

