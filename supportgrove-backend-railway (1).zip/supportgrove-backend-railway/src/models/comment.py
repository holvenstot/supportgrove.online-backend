"""
Comment model for SupportGrove
Handles comment data and database operations
"""

import sqlite3
from datetime import datetime

class Comment:
    def __init__(self, db_path='supportgrove.db'):
        self.db_path = db_path
    
    def create_comment(self, story_id, content, author_name=None, parent_id=None):
        """Create a new comment"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO comments (story_id, parent_id, content, author_name)
                VALUES (?, ?, ?, ?)
            ''', (story_id, parent_id, content, author_name))
            
            comment_id = cursor.lastrowid
            conn.commit()
            
            # Update story comment count
            self._update_story_comment_count(story_id)
            
            return self.get_comment(comment_id)
        
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def get_comment(self, comment_id):
        """Get a comment by ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT id, story_id, parent_id, content, author_name, created_at
                FROM comments WHERE id = ?
            ''', (comment_id,))
            
            row = cursor.fetchone()
            if row:
                return self._row_to_dict(row)
            return None
        
        finally:
            conn.close()
    
    def get_comments_by_story(self, story_id):
        """Get all comments for a story, organized by thread"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT id, story_id, parent_id, content, author_name, created_at
                FROM comments 
                WHERE story_id = ?
                ORDER BY created_at ASC
            ''', (story_id,))
            
            rows = cursor.fetchall()
            comments = [self._row_to_dict(row) for row in rows]
            
            # Organize into threaded structure
            return self._organize_comments(comments)
        
        finally:
            conn.close()
    
    def delete_comment(self, comment_id):
        """Delete a comment and its replies"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Get story_id before deletion for count update
            cursor.execute('SELECT story_id FROM comments WHERE id = ?', (comment_id,))
            result = cursor.fetchone()
            if not result:
                return False
            
            story_id = result[0]
            
            # Delete replies first
            cursor.execute('DELETE FROM comments WHERE parent_id = ?', (comment_id,))
            
            # Delete the comment
            cursor.execute('DELETE FROM comments WHERE id = ?', (comment_id,))
            
            conn.commit()
            
            # Update story comment count
            self._update_story_comment_count(story_id)
            
            return cursor.rowcount > 0
        
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def _update_story_comment_count(self, story_id):
        """Update the comment count for a story"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                UPDATE stories 
                SET comment_count = (
                    SELECT COUNT(*) FROM comments WHERE story_id = ?
                )
                WHERE id = ?
            ''', (story_id, story_id))
            
            conn.commit()
        
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def _organize_comments(self, comments):
        """Organize flat comment list into threaded structure"""
        comment_dict = {comment['id']: comment for comment in comments}
        threaded_comments = []
        
        for comment in comments:
            comment['replies'] = []
            
            if comment['parent_id'] is None:
                # Top-level comment
                threaded_comments.append(comment)
            else:
                # Reply to another comment
                parent = comment_dict.get(comment['parent_id'])
                if parent:
                    parent['replies'].append(comment)
        
        return threaded_comments
    
    def _row_to_dict(self, row):
        """Convert database row to dictionary"""
        return {
            'id': row[0],
            'story_id': row[1],
            'parent_id': row[2],
            'content': row[3],
            'author_name': row[4] or 'Anonymous',
            'created_at': row[5],
            'replies': []  # Will be populated by _organize_comments
        }

