"""
Sharing model for SupportGrove
Handles story forwarding and sharing functionality
"""

import sqlite3
import uuid
import smtplib
from email.mime.text import MimeText
from email.mime.multipart import MimeMultipart
from datetime import datetime, timedelta
import os

class Sharing:
    def __init__(self, db_path='supportgrove.db'):
        self.db_path = db_path
    
    def create_share_link(self, story_id, sender_name=None, personal_message=None, expires_in_days=30):
        """Create a shareable link for a story"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            share_id = str(uuid.uuid4())
            expires_at = datetime.utcnow() + timedelta(days=expires_in_days) if expires_in_days else None
            
            cursor.execute('''
                INSERT INTO sharing (share_id, story_id, sender_name, personal_message, expires_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (share_id, story_id, sender_name, personal_message, expires_at))
            
            conn.commit()
            
            # Get the base URL from environment or use default
            base_url = os.environ.get('FRONTEND_URL', 'https://supportgrove.online')
            share_url = f"{base_url}/shared/{share_id}"
            
            return {
                'share_id': share_id,
                'share_url': share_url,
                'expires_at': expires_at.isoformat() if expires_at else None
            }
        
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def get_shared_story(self, share_id):
        """Get a story by share ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT s.share_id, s.sender_name, s.personal_message, s.expires_at, s.view_count,
                       st.id, st.title, st.content, st.category, st.hashtags, st.author_name,
                       st.created_at, st.reaction_hearts, st.reaction_hugs, st.reaction_sparkles,
                       st.comment_count
                FROM sharing s
                JOIN stories st ON s.story_id = st.id
                WHERE s.share_id = ?
            ''', (share_id,))
            
            row = cursor.fetchone()
            if not row:
                return None
            
            # Check if link has expired
            if row[3]:  # expires_at
                expires_at = datetime.fromisoformat(row[3])
                if datetime.utcnow() > expires_at:
                    return None
            
            # Increment view count
            cursor.execute('''
                UPDATE sharing SET view_count = view_count + 1 
                WHERE share_id = ?
            ''', (share_id,))
            conn.commit()
            
            return {
                'share_info': {
                    'share_id': row[0],
                    'sender_name': row[1],
                    'personal_message': row[2],
                    'view_count': row[4] + 1
                },
                'story': {
                    'id': row[5],
                    'title': row[6],
                    'content': row[7],
                    'category': row[8],
                    'hashtags': row[9],
                    'author_name': row[10] or 'Anonymous',
                    'created_at': row[11],
                    'reactions': {
                        'hearts': row[12] or 0,
                        'hugs': row[13] or 0,
                        'sparkles': row[14] or 0
                    },
                    'comment_count': row[15] or 0
                }
            }
        
        finally:
            conn.close()
    
    def send_story_email(self, story_id, recipient_email, sender_name=None, personal_message=None):
        """Send a story via email"""
        # Get story details
        from models.story import Story
        story_model = Story(self.db_path)
        story = story_model.get_story(story_id)
        
        if not story:
            raise ValueError("Story not found")
        
        # Create share link
        share_data = self.create_share_link(story_id, sender_name, personal_message)
        
        # Compose email
        subject = f"Someone shared a story with you: {story['title']}"
        
        # Create email content
        email_body = self._create_email_body(story, share_data, sender_name, personal_message)
        
        # Send email
        success = self._send_email(recipient_email, subject, email_body)
        
        if success:
            return {
                'success': True,
                'share_url': share_data['share_url'],
                'message': 'Email sent successfully'
            }
        else:
            return {
                'success': False,
                'message': 'Failed to send email'
            }
    
    def _create_email_body(self, story, share_data, sender_name, personal_message):
        """Create formatted email body"""
        sender_text = f"from {sender_name}" if sender_name else "from someone who cares"
        
        email_html = f"""
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #2d5a3d;">A Story Was Shared With You</h2>
                
                <p>You've received a story {sender_text} from the SupportGrove community.</p>
                
                {f'<div style="background: #f0f8f4; padding: 15px; border-left: 4px solid #2d5a3d; margin: 20px 0;"><strong>Personal Message:</strong><br>{personal_message}</div>' if personal_message else ''}
                
                <div style="background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 20px; margin: 20px 0;">
                    <h3 style="color: #2d5a3d; margin-top: 0;">{story['title']}</h3>
                    <p style="color: #666; font-size: 14px;">Category: {story['category']} | By: {story['author_name']}</p>
                    
                    <div style="margin: 15px 0;">
                        {story['content'][:300]}{'...' if len(story['content']) > 300 else ''}
                    </div>
                    
                    <div style="margin: 15px 0;">
                        <span style="background: #e8f5e8; padding: 4px 8px; border-radius: 12px; font-size: 12px; margin-right: 8px;">
                            ❤️ {story['reactions']['hearts']} hearts
                        </span>
                        <span style="background: #e8f5e8; padding: 4px 8px; border-radius: 12px; font-size: 12px; margin-right: 8px;">
                            🤗 {story['reactions']['hugs']} hugs
                        </span>
                        <span style="background: #e8f5e8; padding: 4px 8px; border-radius: 12px; font-size: 12px;">
                            ✨ {story['reactions']['sparkles']} sparkles
                        </span>
                    </div>
                </div>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="{share_data['share_url']}" 
                       style="background: #2d5a3d; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                        Read Full Story & Comments
                    </a>
                </div>
                
                <div style="border-top: 1px solid #eee; padding-top: 20px; margin-top: 30px; font-size: 12px; color: #666;">
                    <p>This story was shared from SupportGrove, a safe, anonymous community where lived experiences become bridges of hope and healing.</p>
                    <p>Visit <a href="https://supportgrove.online" style="color: #2d5a3d;">SupportGrove.Online</a> to share your own story or find support.</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return email_html
    
    def _send_email(self, recipient_email, subject, body):
        """Send email using SMTP"""
        try:
            smtp_server = os.environ.get('SMTP_SERVER', 'smtp.gmail.com')
            smtp_port = int(os.environ.get('SMTP_PORT', '587'))
            smtp_username = os.environ.get('SMTP_USERNAME', '')
            smtp_password = os.environ.get('SMTP_PASSWORD', '')
            
            if not smtp_username or not smtp_password:
                print("Email credentials not configured")
                return False
            
            msg = MimeMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = smtp_username
            msg['To'] = recipient_email
            
            # Add HTML body
            html_part = MimeText(body, 'html')
            msg.attach(html_part)
            
            # Send email
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            server.login(smtp_username, smtp_password)
            server.send_message(msg)
            server.quit()
            
            return True
            
        except Exception as e:
            print(f"Email sending error: {e}")
            return False
    
    def get_share_stats(self, share_id):
        """Get sharing statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT view_count, created_at, expires_at
                FROM sharing WHERE share_id = ?
            ''', (share_id,))
            
            row = cursor.fetchone()
            if row:
                return {
                    'view_count': row[0],
                    'created_at': row[1],
                    'expires_at': row[2],
                    'is_expired': datetime.utcnow() > datetime.fromisoformat(row[2]) if row[2] else False
                }
            return None
        
        finally:
            conn.close()

