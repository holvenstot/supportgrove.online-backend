# SupportGrove Backend - Railway Deployment

This is the backend API for SupportGrove.Online, optimized for deployment on Railway.com.

## 🚀 Quick Deploy to Railway

1. **Upload to GitHub** - Push this backend folder to your GitHub repository
2. **Connect to Railway** - Sign in to Railway with GitHub and select this repository
3. **Auto-Deploy** - Railway automatically detects and deploys the Flask application
4. **Configure Domain** - Add your custom domain in Railway dashboard

## 📁 Project Structure

```
supportgrove-backend-railway/
├── app.py                 # Main Flask application (Railway entry point)
├── requirements.txt       # Python dependencies
├── railway.toml          # Railway deployment configuration
├── .env.example          # Environment variables template
├── README.md             # This file
└── src/                  # Source code
    ├── models/           # Database models
    │   ├── story.py      # Story data model
    │   ├── comment.py    # Comment data model
    │   ├── user.py       # User management
    │   └── sharing.py    # Story forwarding/sharing
    └── routes/           # API endpoints
        ├── stories.py    # Story CRUD operations
        ├── comments.py   # Comment operations
        ├── categories.py # Category management
        ├── notifications.py # Notification system
        └── sharing.py    # Forwarding functionality
```

## ✨ Features Included

### 🏠 **Core Platform**
- Anonymous story sharing with guided questions
- Six support categories with inclusive descriptions
- Story reactions (hearts, hugs, sparkles)
- Threaded commenting system
- Real-time notifications

### 📤 **Forwarding System**
- Generate shareable links for stories
- Email forwarding with beautiful templates
- Personal messages and sender attribution
- Link expiration and view tracking

### 🛡️ **Privacy & Safety**
- Anonymous user sessions
- Content sanitization and validation
- Pseudonym support for consistency
- Basic rate limiting and moderation tools

### 🌍 **Inclusive Support**
- Expanded trauma category including:
  - Racial trauma
  - Sexism and gender-based discrimination
  - Religious abuse
  - Gender fluidity shaming
  - Multigenerational family dysfunctionality

## 🔧 Railway Configuration

### **Automatic Detection**
Railway automatically detects this as a Python Flask application and:
- Installs dependencies from `requirements.txt`
- Uses `railway.toml` for deployment configuration
- Starts the application with `python app.py`
- Provides health check endpoint at `/api/health`

### **Environment Variables**
Set these in Railway dashboard:
- `SECRET_KEY` - Flask secret key for sessions
- `CORS_ORIGINS` - Allowed frontend origins (use `*` for development)
- `SMTP_USERNAME` - Email for forwarding feature (optional)
- `SMTP_PASSWORD` - Email password for forwarding (optional)
- `FRONTEND_URL` - Your frontend URL for share links

### **Database**
- Uses SQLite for simplicity and Railway compatibility
- Database file is automatically created and persisted
- All tables are created automatically on first run
- Categories are seeded automatically

## 📡 API Endpoints

### **Stories**
- `GET /api/stories` - Get stories with optional category filter
- `POST /api/stories` - Create new story
- `GET /api/stories/{id}` - Get specific story
- `POST /api/stories/{id}/reactions` - Add/remove reactions
- `DELETE /api/stories/{id}` - Delete story (admin)

### **Comments**
- `GET /api/stories/{id}/comments` - Get story comments
- `POST /api/stories/{id}/comments` - Create comment
- `POST /api/comments/{id}/reply` - Reply to comment
- `DELETE /api/comments/{id}` - Delete comment (admin)

### **Categories**
- `GET /api/categories` - Get all categories with story counts
- `GET /api/categories/{id}` - Get specific category
- `POST /api/categories/seed` - Seed initial categories
- `GET /api/categories/stats` - Get category statistics

### **Sharing/Forwarding**
- `POST /api/stories/{id}/share` - Create shareable link
- `GET /api/shared/{share_id}` - Get shared story
- `POST /api/stories/{id}/email` - Send story via email
- `GET /api/shared/{share_id}/stats` - Get sharing stats

### **Notifications**
- `GET /api/notifications` - Get recent notifications
- `POST /api/notifications` - Create notification
- `POST /api/notifications/{id}/read` - Mark as read
- `GET /api/notifications/unread-count` - Get unread count

### **Health Check**
- `GET /api/health` - Railway health check endpoint

## 🌐 CORS Configuration

The backend is configured to accept requests from any origin (`*`) by default. For production, update the `CORS_ORIGINS` environment variable to your specific frontend domain:

```
CORS_ORIGINS=https://supportgrove.online
```

## 📧 Email Configuration (Optional)

To enable the story forwarding via email feature:

1. **Gmail Setup** (recommended):
   - Enable 2-factor authentication
   - Generate an app-specific password
   - Use your Gmail address and app password

2. **Environment Variables**:
   ```
   SMTP_SERVER=smtp.gmail.com
   SMTP_PORT=587
   SMTP_USERNAME=your-email@gmail.com
   SMTP_PASSWORD=your-app-password
   ```

3. **Other Email Providers**:
   - Update SMTP_SERVER and SMTP_PORT accordingly
   - Ensure your provider supports STARTTLS

## 🔒 Security Features

- **Content Sanitization** - Removes HTML/script tags from user input
- **Input Validation** - Validates all user inputs and API parameters
- **Anonymous Sessions** - No personal data collection
- **Rate Limiting Ready** - Framework for implementing rate limits
- **SQL Injection Protection** - Parameterized queries throughout

## 📊 Database Schema

### **Stories Table**
- id, title, content, category, hashtags
- author_name, created_at, updated_at
- reaction_hearts, reaction_hugs, reaction_sparkles
- comment_count

### **Comments Table**
- id, story_id, parent_id (for threading)
- content, author_name, created_at

### **Categories Table**
- id, name, description, color, icon
- story_count (calculated)

### **Sharing Table**
- id, share_id (UUID), story_id
- sender_name, personal_message
- created_at, expires_at, view_count

### **Notifications Table**
- id, story_id, comment_id, type, message
- created_at, read_at

## 🚀 Deployment Steps

1. **Prepare Repository**:
   ```bash
   # Upload this backend folder to GitHub
   git add .
   git commit -m "Add SupportGrove backend for Railway"
   git push origin main
   ```

2. **Deploy to Railway**:
   - Go to [railway.app/new](https://railway.app/new)
   - Click "Deploy from GitHub repo"
   - Select your repository
   - Railway auto-detects and deploys

3. **Configure Environment**:
   - Set environment variables in Railway dashboard
   - Add custom domain for your backend API

4. **Test Deployment**:
   - Visit `/api/health` to verify deployment
   - Test API endpoints with your frontend
   - Verify database initialization

## 🔧 Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Set environment variables
cp .env.example .env
# Edit .env with your values

# Run the application
python app.py
```

The API will be available at `http://localhost:5000`

## 📈 Scaling

Railway automatically handles:
- **Traffic Scaling** - Automatic scaling based on demand
- **Database Persistence** - SQLite file is preserved across deployments
- **SSL Certificates** - Automatic HTTPS for custom domains
- **Monitoring** - Built-in logs and metrics

For high-traffic scenarios, consider:
- Upgrading to Railway Pro plan
- Implementing Redis for caching
- Adding database connection pooling
- Setting up monitoring alerts

## 🆘 Troubleshooting

### **Common Issues**:

1. **Build Fails**:
   - Check `requirements.txt` for correct package versions
   - Verify Python version compatibility

2. **Database Errors**:
   - Ensure SQLite is supported (it is on Railway)
   - Check file permissions for database creation

3. **CORS Errors**:
   - Verify `CORS_ORIGINS` environment variable
   - Check frontend URL configuration

4. **Email Not Working**:
   - Verify SMTP credentials
   - Check email provider settings
   - Test with a simple email client first

### **Logs and Debugging**:
- View logs in Railway dashboard
- Use `/api/health` endpoint to verify service status
- Check environment variables in Railway settings

## 📞 Support

For deployment assistance:
1. Check Railway documentation
2. Verify all environment variables are set
3. Test API endpoints individually
4. Review application logs for specific errors

Your SupportGrove backend is ready for production deployment on Railway! 🌱

